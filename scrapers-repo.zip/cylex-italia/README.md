# Cylex Scraper

Scraper con interfaccia grafica (Tkinter) per Cylex Italia.

## Funzionalità
- Selezione geografica Regione → Provincia → Città (o intera provincia)
- Scarica tutte le pagine di risultati per ogni città
- Estrae anche l'email dalla pagina di dettaglio (gestisce l'offuscamento Cloudflare Email Protection)
- Esporta i risultati in Excel (.xlsx), ordinati alfabeticamente
- Pulsante Stop per interrompere la ricerca in corso

## Installazione
```bash
pip install -r requirements.txt
```

## Uso
```bash
python cylex_scraper.py
```

Al primo avvio viene scaricato automaticamente il database dei comuni italiani.
